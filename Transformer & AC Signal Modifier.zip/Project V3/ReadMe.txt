Save Button

File path of text file needs to be updated to new location in SaveButton callback function.